<?php

function sebian_get_demo_array($dir_url, $dir_path){

    $demo = array(
        'home-01' => array(
            'title' 		=> 'Fashion 01',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-01.zip',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-01.json',
            'preview'		=> $dir_url  . 'home-01.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 01',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-01',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-01'
        ),
        'home-02' => array(
            'title' 		=> 'Fashion 02',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-02.zip',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-02.json',
            'preview'		=> $dir_url  . 'home-02.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 02',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-02',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-02'
        ),
        'home-03' => array(
            'title' 		=> 'Fashion 03',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-03.zip',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-03.json',
            'preview'		=> $dir_url  . 'home-03.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 03',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-03',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-03'
        ),
        'home-04' => array(
            'title' 		=> 'Fashion 04',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-04.zip',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-04.json',
            'preview'		=> $dir_url  . 'home-04.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 04',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-04',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-04'
        ),
        'home-05' => array(
            'title' 		=> 'Fashion 05',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-05.json',
            'preview'		=> $dir_url  . 'home-05.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 05',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-05',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-05'
        ),
        'home-06' => array(
            'title' 		=> 'Fashion 06',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-06.zip',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-06.json',
            'preview'		=> $dir_url  . 'home-06.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 06',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-06',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-06'
        ),
        'home-07' => array(
            'title' 		=> 'Construction 01',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-07.zip',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-07.json',
            'preview'		=> $dir_url  . 'home-07.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 07',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-07',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-07'
        ),
        'home-08' => array(
            'title' 		=> 'Construction 02',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-08.zip',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-08.json',
            'preview'		=> $dir_url  . 'home-08.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 08',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-08',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-08'
        ),
        'home-09' => array(
            'title' 		=> 'Furniture',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-09.zip',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-09.json',
            'preview'		=> $dir_url  . 'home-09.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 09',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-09',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-09'
        ),
        'home-10' => array(
            'title' 		=> 'Sport',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-10.json',
            'preview'		=> $dir_url  . 'home-10.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 10',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-10',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-10'
        ),
        'home-11' => array(
            'title' 		=> 'Cosmetic',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-11.zip',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-11.json',
            'preview'		=> $dir_url  . 'home-11.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 11',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-11',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-11'
        ),
        'home-12' => array(
            'title' 		=> 'Watches',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-12.zip',
            'content' 		=> $dir_path . 'sebian-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-12.json',
            'preview'		=> $dir_url  . 'home-12.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 12',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'home-12',
            'demo_url'      => 'http://sebian.la-studioweb.com/home-12'
        )
    );

    return $demo;
}