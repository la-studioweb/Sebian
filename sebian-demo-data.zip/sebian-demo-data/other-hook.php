<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

add_filter('woocommerce_product_related_posts_relate_by_category', '__return_false');
add_filter('woocommerce_product_related_posts_relate_by_tag', '__return_false');

add_filter('woocommerce_product_related_posts_force_display', '__return_true');

add_filter('sebian/filter/product_per_page', 'sebian_preset_product_per_page');
function sebian_preset_product_per_page( $value ){
    if(isset($_GET['la_preset']) && ( $_GET['la_preset'] == 'shop-fullwidth' || $_GET['la_preset'] == 'shop-fullwidth2')){
        return 10;
    }
    return $value;
}

add_filter('body_class', 'sebian_preset_add_body_classes');

function sebian_preset_add_body_classes( $class ){
    $class[] = 'isLaWebRoot';
    return $class;
}

add_filter( 'get_avatar_url', 'sebian_preset_new_gravatar', 10, 3);
function sebian_preset_new_gravatar ( $url, $id_or_email, $args ) {
    if ( is_object( $id_or_email ) && isset( $id_or_email->comment_author_email ) ) {
        if ( strpos($id_or_email->comment_author_email, 'la-studioweb.com') !== false ){
            return home_url('/wp-content/uploads/2017/04/avatar.png');
        }
        if ( $id_or_email->comment_author_email == 'info@localhost.com' ){
            return Sebian::$template_dir_url . '/assets/images/avatar-1.jpg';
        }
        if ( $id_or_email->comment_author_email == 'info2@localhost.com' ){
            return Sebian::$template_dir_url . '/assets/images/avatar-2.jpg';
        }
    }
    if ( $id_or_email == 'dpv.0990@gmail.com' || $id_or_email == 'info@la-studioweb.com' ){
        return Sebian::$template_dir_url . '/assets/images/avatar.jpg';
    }
    return $url;

}

add_action( 'pre_get_posts', 'sebian_preset_change_blog_posts' );
function sebian_preset_change_blog_posts( $query ){
    if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-masonry'){
        if ( $query->is_home() && $query->is_main_query() ) {
            $query->set( 'posts_per_page', 8 );
        }
    }
    if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-2-columns'){
        if ( $query->is_home() && $query->is_main_query() ) {
            $query->set( 'post__not_in', array(853) );
            $query->set( 'posts_per_page', 4 );
        }
    }
    if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-3-columns'){
        if ( $query->is_home() && $query->is_main_query() ) {
            $query->set( 'posts_per_page', 6 );
        }
    }
    if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-4-columns'){
        if ( $query->is_home() && $query->is_main_query() ) {
            $query->set( 'posts_per_page', 8 );
        }
    }
}

add_filter('sebian/filter/blog/post_thumbnail', 'sebian_preset_modify_thumbnail_for_blog_masonry', 10, 2);
function sebian_preset_modify_thumbnail_for_blog_masonry( $size, $loop ){
    if(isset($_GET['la_preset']) && isset($loop['loop_index'])){
        if($_GET['la_preset'] == 'blog-masonry'){
            $idx = absint($loop['loop_index']);
            $ref = array(
                array(270,290),
                array(270,390),
                array(270,234),
                array(270,180),
                array(270,290),
                array(270,390),
                array(270,234),
                array(270,365)
            );
            if(isset($ref[$idx-1])){
                return $ref[$idx-1];
            }
        }
    }
    return $size;
}

add_filter('sebian/filter/portfolio/post_thumbnail', 'sebian_preset_modify_thumbnail_for_portfolio_masonry', 10, 2);
function sebian_preset_modify_thumbnail_for_portfolio_masonry( $size, $loop ){
    if(isset($loop['loop_layout']) && isset($loop['loop_index']) && $loop['loop_layout'] == 'masonry' && $size == array(270,0)){
        if(isset($loop['column_type']) && $loop['column_type'] != 'custom'){
            $idx = absint($loop['loop_index']);
            $ref = array(
                array(270,320),
                array(270,440),
                array(270,305),
                array(270,450),
                array(270,320),
                array(270,440),
                array(270,305),
                array(270,450),
                array(270,320),
                array(270,440),
                array(270,305),
                array(270,450),
            );
            if(isset($ref[$idx-1])){
                return $ref[$idx-1];
            }
        }
    }
    return $size;
}