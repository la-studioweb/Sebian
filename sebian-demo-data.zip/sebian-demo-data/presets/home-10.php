<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_sebian_preset_home_10(){
    return array(
        array(
            'key' => 'header_layout',
            'value' => 2
        ),
        array (
            'key' => 'primary_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'header_link_hover_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'mm_lv_1_hover_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'header_top_link_hover_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'transparency_header_link_hover_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'transparency_header_top_link_hover_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'offcanvas_link_hover_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'mb_lv_1_hover_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'page_title_bar_link_hover_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'footer_link_hover_color',
            'value' => '#d3ca00',
        ),

        array (
            'key' => 'footer_copyright_link_color',
            'value' => '#d3ca00',
        )
    );
}