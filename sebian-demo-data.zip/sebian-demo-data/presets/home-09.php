<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_sebian_preset_home_09(){
    return array(
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'logo_transparency',
            'value' => 160
        ),

        array(
            'key' => 'logo_transparency_2x',
            'value' => 161
        ),

        array(
            'key' => 'transparency_header_top_text_color',
            'value' => '#898989'
        ),

        array(
            'key' => 'transparency_header_top_link_color',
            'value' => '#898989'
        ),

        array(
            'key' => 'transparency_header_text_color',
            'value' => '#898989'
        ),

        array(
            'key' => 'transparency_header_link_color',
            'value' => '#898989'
        ),

        array(
            'key' => 'transparency_mm_lv_1_color',
            'value' => '#898989'
        ),

        array (
            'key' => 'primary_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'header_link_hover_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'mm_lv_1_hover_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'header_top_link_hover_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'transparency_header_link_hover_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'transparency_header_top_link_hover_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'offcanvas_link_hover_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'mb_lv_1_hover_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'page_title_bar_link_hover_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'footer_link_hover_color',
            'value' => '#6d831c',
        ),

        array (
            'key' => 'footer_copyright_link_color',
            'value' => '#6d831c',
        )
    );
}