<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_sebian_preset_blog_3_columns(){
    return array(
        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),
        array(
            'key' => 'blog_small_layout',
            'value' => 'off'
        ),
        array(
            'key' => 'blog_design',
            'value' => 'grid_3'
        ),
        array(
            'key' => 'blog_thumbnail_size',
            'value' => '370x340'
        ),
        array(
            'key' => 'blog_post_column',
            'value' => array (
                'xlg'   => '3',
                'lg'    => '3',
                'md'    => '2',
                'sm'    => '2',
                'xs'    => '1',
                'mb'    => '1'
            )
        ),
        array(
            'key' => 'blog_excerpt_length',
            'value' => 28
        ),
        array(
            'key' => 'format_content_blog',
            'value' => 'off'
        ),
        array(
            'key' => 'blog_masonry',
            'value' => 'off'
        ),
        array(
            'filter_name' => 'sebian/filter/page_title',
            'value' => '<header><div class="page-title h1">BLOG 03 COLUMNS</div></header>'
        )
    );
}