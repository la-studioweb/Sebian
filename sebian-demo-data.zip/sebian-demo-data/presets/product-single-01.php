<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_sebian_preset_product_single_01(){
    return array(
        array(
            'key' => 'woocommerce_product_page_design',
            'value' => 1
        ),
        array(
            'filter_name' => 'sebian/filter/page_title',
            'value' => '<header><div class="page-title h1">SHOP DETAIL 01</div></header>'
        )
    );
}