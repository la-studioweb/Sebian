<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_sebian_preset_shop_2_columns(){
    return array(
        array(
            'key' => 'layout_archive_product',
            'value' => 'col-1c'
        ),

        array(
            'key' => 'woocommerce_shop_page_columns',
            'value' => array(
                'xlg'   => '2',
                'lg'    => '2',
                'md'    => '2',
                'sm'    => '2',
                'xs'    => '2',
                'mb'    => '1'
            )
        ),

        array(
            'filter_name' => 'sebian/filter/page_title',
            'value' => '<header><div class="page-title h1">SHOP 2 COLUMNS</div></header>'
        )
    );
}