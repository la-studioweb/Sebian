<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_sebian_preset_blog_left_sidebar(){
    return array(
        array(
            'key' => 'layout_blog',
            'value' => 'col-2cl'
        ),
        array(
            'key' => 'blog_design',
            'value' => 'grid_4'
        ),
        array(
            'key' => 'blog_thumbnail_size',
            'value' => '870x370'
        ),
        array(
            'key' => 'blog_post_column',
            'value' => array (
                'xlg'   => '1',
                'lg'    => '1',
                'md'    => '1',
                'sm'    => '1',
                'xs'    => '1',
                'mb'    => '1'
            )
        ),
        array(
            'key' => 'blog_excerpt_length',
            'value' => 100
        ),
        array(
            'key' => 'format_content_blog',
            'value' => 'off'
        ),
        array(
            'key' => 'blog_masonry',
            'value' => 'off'
        ),
        array(
            'filter_name' => 'sebian/filter/page_title',
            'value' => '<header><div class="page-title h1">BLOG LEFT SIDEBAR</div></header>'
        )
    );
}